module.exports = {
    url : "mongodb+srv://vatsalpatel1841103:Ram%4013579@vpcluster.hexdv.mongodb.net/sample_mflix"
};